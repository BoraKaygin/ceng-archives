import java.util.ArrayList;

public class CengTree
{
    public CengTreeNode root;
    // Any extra attributes...
    public ArrayList<CengTreeNode> visitedNodes;

    public CengTree(Integer order)
    {
        CengTreeNode.order = order;
        // TODO: Initialize the class
        root = new CengTreeNodeLeaf(null);
    }

    public void addBook(CengBook book)
    {
        // TODO: Insert Book to Tree
        if (root.getType() == CengNodeType.Leaf) {
            CengTreeNodeLeaf leaf = (CengTreeNodeLeaf) root;
            if (leaf.bookCount() < 2 * CengTreeNode.order) {
                leaf.addBook(book);
            } else {
                leaf.addBook(book);
                CengTreeNodeInternal internal = new CengTreeNodeInternal(null);
                internal.addKey(leaf.getBook(CengTreeNode.order).getBookID());
                CengTreeNodeLeaf left = new CengTreeNodeLeaf(internal);
                CengTreeNodeLeaf right = new CengTreeNodeLeaf(internal);
                for (int i = 0; i < leaf.bookCount(); i++) {
                    if (i < CengTreeNode.order) {
                        left.addBook(leaf.getBook(i));
                    } else {
                        right.addBook(leaf.getBook(i));
                    }
                }
                internal.addChild(left);
                internal.addChild(right);
                root = internal;
            }
        } else {
            CengTreeNodeInternal internal = (CengTreeNodeInternal) root;
            int i = 0;
            while (i < internal.keyCount() && internal.keyAtIndex(i) < book.getBookID()) {
                i++;
            }
            ArrayList <CengTreeNode> children = internal.getAllChildren();
            try {
                addBookToNode(children.get(i), book);
            } catch (LeafNodeOverflow leafNodeOverflow) {
                CengTreeNodeLeaf leaf = (CengTreeNodeLeaf) children.get(i);
                CengTreeNodeLeaf left = new CengTreeNodeLeaf(internal);
                CengTreeNodeLeaf right = new CengTreeNodeLeaf(internal);
                for (int j = 0; j < leaf.bookCount(); j++) {
                    if (j < CengTreeNode.order) {
                        left.addBook(leaf.getBook(j));
                    } else {
                        right.addBook(leaf.getBook(j));
                    }
                }
                children.set(i, left);
                children.add(i + 1, right);
                internal.addKey(right.getBook(0).getBookID());
            } catch (InternalNodeOverflow internalNodeOverflow) {
                CengTreeNodeInternal internalChild = (CengTreeNodeInternal) children.get(i);
                CengTreeNodeInternal left = new CengTreeNodeInternal(internal);
                CengTreeNodeInternal right = new CengTreeNodeInternal(internal);
                for (int j = 0; j < internalChild.keyCount(); j++) {
                    if (j < CengTreeNode.order) {
                        left.addKey(internalChild.keyAtIndex(j));
                    } else if (j == CengTreeNode.order) {
                        internal.addKey(internalChild.keyAtIndex(j));
                    } else {
                        right.addKey(internalChild.keyAtIndex(j));
                    }
                }
                for (int j = 0; j < internalChild.getAllChildren().size(); j++) {
                    if (j < CengTreeNode.order + 1) {
                        left.addChild(internalChild.getAllChildren().get(j));
                    } else {
                        right.addChild(internalChild.getAllChildren().get(j));
                    }
                }
                children.set(i, left);
                children.add(i + 1, right);
            }
            if (internal.keyCount() > 2 * CengTreeNode.order) {
                CengTreeNodeInternal newRoot = new CengTreeNodeInternal(null);
                CengTreeNodeInternal left = new CengTreeNodeInternal(newRoot);
                CengTreeNodeInternal right = new CengTreeNodeInternal(newRoot);
                for (int j = 0; j < internal.keyCount(); j++) {
                    if (j < CengTreeNode.order) {
                        left.addKey(internal.keyAtIndex(j));
                    } else if (j == CengTreeNode.order) {
                        newRoot.addKey(internal.keyAtIndex(j));
                    } else {
                        right.addKey(internal.keyAtIndex(j));
                    }
                }
                for (int j = 0; j < internal.getAllChildren().size(); j++) {
                    if (j < CengTreeNode.order + 1) {
                        left.addChild(internal.getAllChildren().get(j));
                    } else {
                        right.addChild(internal.getAllChildren().get(j));
                    }
                }
                newRoot.addChild(left);
                newRoot.addChild(right);
                root = newRoot;
            }
        }
    }

    public ArrayList<CengTreeNode> searchBook(Integer bookID)
    {
        // TODO: Search within whole Tree, return visited nodes.
        // Return null if not found.
        if (!searchFind(bookID, root)) {
            System.out.print("Could not find " + bookID + ".\n");
            return null;
        }
        visitedNodes = new ArrayList<>();
        searchPrint(bookID, root, 0);
        return visitedNodes;
    }

    public void printTree()
    {
        // TODO: Print the whole tree to console
        printNode(root, 0);
    }

    // Any extra functions...

    private void addBookToNode(CengTreeNode node, CengBook book) throws LeafNodeOverflow, InternalNodeOverflow {
        // Recursively add book to nodes reaching all the way down to leaf nodes. Split nodes if necessary.
        if (node.getType() == CengNodeType.Leaf) {
            CengTreeNodeLeaf leaf = (CengTreeNodeLeaf) node;
            leaf.addBook(book);
            if (leaf.bookCount() > 2 * CengTreeNode.order) {
                throw new LeafNodeOverflow();
            }
        }
        else {
            CengTreeNodeInternal internal = (CengTreeNodeInternal) node;
            int i = 0;
            while (i < internal.keyCount() && internal.keyAtIndex(i) < book.getBookID()) {
                i++;
            }
            ArrayList <CengTreeNode> children = internal.getAllChildren();
            try {
                addBookToNode(children.get(i), book);
            } catch (LeafNodeOverflow leafNodeOverflow) {
                CengTreeNodeLeaf leaf = (CengTreeNodeLeaf) children.get(i);
                CengTreeNodeLeaf left = new CengTreeNodeLeaf(internal);
                CengTreeNodeLeaf right = new CengTreeNodeLeaf(internal);
                for (int j = 0; j < leaf.bookCount(); j++) {
                    if (j < CengTreeNode.order) {
                        left.addBook(leaf.getBook(j));
                    } else {
                        right.addBook(leaf.getBook(j));
                    }
                }
                children.set(i, left);
                children.add(i + 1, right);
                internal.addKey(right.getBook(0).getBookID());
                if (internal.keyCount() > 2 * CengTreeNode.order) {
                    throw new InternalNodeOverflow();
                }
            } catch (InternalNodeOverflow internalNodeOverflow) {
                CengTreeNodeInternal internalChild = (CengTreeNodeInternal) children.get(i);
                CengTreeNodeInternal left = new CengTreeNodeInternal(internal);
                CengTreeNodeInternal right = new CengTreeNodeInternal(internal);
                for (int j = 0; j < internalChild.keyCount(); j++) {
                    if (j < CengTreeNode.order) {
                        left.addKey(internalChild.keyAtIndex(j));
                    } else if (j == CengTreeNode.order) {
                        internal.addKey(internalChild.keyAtIndex(j));
                    } else {
                        right.addKey(internalChild.keyAtIndex(j));
                    }
                }
                for (int j = 0; j < internalChild.getAllChildren().size(); j++) {
                    if (j < CengTreeNode.order + 1) {
                        left.addChild(internalChild.getAllChildren().get(j));
                    } else {
                        right.addChild(internalChild.getAllChildren().get(j));
                    }
                }
                children.set(i, left);
                children.add(i + 1, right);
                if (internal.keyCount() > 2 * CengTreeNode.order) {
                    throw new InternalNodeOverflow();
                }
            }
        }
    }

    static class LeafNodeOverflow extends Exception {
        /*
        public LeafNodeOverflow(String errorMessage) {
            super(errorMessage);
        }
        */
    }

    static class InternalNodeOverflow extends Exception {
        /*
        public InternalNodeOverflow(String errorMessage) {
            super(errorMessage);
        }
        */
    }
    public void printTabs(int depth) {
        for (int i = 0; i < depth; i++) {
            System.out.print("\t");
        }
    }
    public void printNode(CengTreeNode node, int depth) {
        if (node.getType() == CengNodeType.Leaf) {
            CengTreeNodeLeaf leaf = (CengTreeNodeLeaf) node;
            printTabs(depth);
            System.out.print("<data>\n");
            for (int i = 0; i < leaf.bookCount(); i++) {
                printTabs(depth);
                CengBook book = leaf.getBook(i);
                System.out.print("<record>" + book.fullName() + "</record>" + "\n");
            }
            printTabs(depth);
            System.out.print("</data>\n");
        }
        else {
            CengTreeNodeInternal internal = (CengTreeNodeInternal) node;
            printTabs(depth);
            System.out.print("<index>\n");
            for (int i = 0; i < internal.keyCount(); i++) {
                printTabs(depth);
                System.out.print(internal.keyAtIndex(i) + "\n");
            }
            printTabs(depth);
            System.out.print("</index>\n");
            ArrayList <CengTreeNode> children = internal.getAllChildren();
            for (int i = 0; i < internal.getAllChildren().size(); i++) {
                printNode(children.get(i), depth + 1);
            }
        }
    }

    public void searchPrint(Integer bookID, CengTreeNode node, int depth) {
        visitedNodes.add(node);
        if (node.getType() == CengNodeType.Leaf){
            CengTreeNodeLeaf leaf = (CengTreeNodeLeaf) node;
            printTabs(depth);
            for (int i = 0; i < leaf.bookCount(); i++){
                if (leaf.getBook(i).getBookID().equals(bookID)) {
                    CengBook book = leaf.getBook(i);
                    System.out.print("<record>" + book.fullName() + "</record>" + "\n");
                    return;
                }
            }
        }
        else {
            CengTreeNodeInternal internal = (CengTreeNodeInternal) node;
            int i = 0;
            while (i < internal.keyCount() && internal.keyAtIndex(i) <= bookID) {
                i++;
            }
            printTabs(depth);
            System.out.print("<index>\n");
            for (int j = 0; j < i; j++) {
                printTabs(depth);
                System.out.print(internal.keyAtIndex(j) + "\n");
            }
            printTabs(depth);
            System.out.print("</index>\n");
            ArrayList <CengTreeNode> children = internal.getAllChildren();
            searchPrint(bookID, children.get(i), depth + 1);
        }
    }

    public boolean searchFind(Integer bookID, CengTreeNode node) {
        if (node.getType() == CengNodeType.Leaf) {
            CengTreeNodeLeaf leaf = (CengTreeNodeLeaf) node;
            for (int i = 0; i < leaf.bookCount(); i++) {
                if (leaf.getBook(i).getBookID().equals(bookID)) {
                    return true;
                }
            }
            return false;
        }
        else {
            CengTreeNodeInternal internal = (CengTreeNodeInternal) node;
            int i = 0;
            while (i < internal.keyCount() && internal.keyAtIndex(i) <= bookID) {
                i++;
            }
            ArrayList <CengTreeNode> children = internal.getAllChildren();
            return searchFind(bookID, children.get(i));
        }
    }
}
