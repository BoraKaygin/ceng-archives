import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

@SuppressWarnings("CallToPrintStackTrace")
public class CengTreeParser
{
    public static ArrayList<CengBook> parseBooksFromFile(String filename)
    {
        ArrayList<CengBook> bookList = new ArrayList<CengBook>();

        // You need to parse the input file in order to use GUI tables.
        // TODO: Parse the input file, and convert them into CengBooks
        ArrayList<String> bookLines = new ArrayList<String>();
        try {
            bookLines = (ArrayList<String>) Files.readAllLines(Paths.get(filename), StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Iterator<String> it = bookLines.iterator();
        while (it.hasNext()){
            String currentLine = it.next();
            String[] fields = currentLine.split("\\|");
            CengBook currentBook = new CengBook(Integer.parseInt(fields[0]), fields[1], fields[2], fields[3]);
            bookList.add(currentBook);
        }
        return bookList;
    }

    public static void startParsingCommandLine() throws IOException
    {
        // TODO: Start listening and parsing command line -System.in-.
        // There are 4 commands:
        // 1) quit : End the app, gracefully. Print nothing, call nothing, just break off your command line loop.
        // 2) add : Parse and create the book, and call CengBookRunner.addBook(newlyCreatedBook).
        // 3) search : Parse the bookID, and call CengBookRunner.searchBook(bookID).
        // 4) print : Print the whole tree, call CengBookRunner.printTree().

        // Commands (quit, add, search, print) are case-insensitive.

        while (true){
            Scanner scanner = new Scanner(System.in);
            String command = scanner.nextLine();
            if (command.equals("quit")){
                break;
            }
            else if (command.equals("print")) {
                CengBookRunner.printTree();
            } else {
                String[] fields = command.split("\\|");
                if (fields[0].equals("add")) {
                    CengBook currentBook = new CengBook(Integer.parseInt(fields[1]), fields[2], fields[3], fields[4]);
                    CengBookRunner.addBook(currentBook);
                } else if (fields[0].equals("search")) {
                    CengBookRunner.searchBook(Integer.parseInt(fields[1]));
                }
            }
        }
    }
}
