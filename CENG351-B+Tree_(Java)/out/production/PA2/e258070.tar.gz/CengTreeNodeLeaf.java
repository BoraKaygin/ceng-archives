import java.util.ArrayList;

public class CengTreeNodeLeaf extends CengTreeNode
{
    private ArrayList<CengBook> books;
    // TODO: Any extra attributes

    public CengTreeNodeLeaf(CengTreeNode parent)
    {
        super(parent);

        // TODO: Extra initializations
        type = CengNodeType.Leaf;
        books = new ArrayList<>();
    }

    // GUI Methods - Do not modify
    public int bookCount()
    {
        return books.size();
    }
    public Integer bookKeyAtIndex(Integer index)
    {
        if(index >= this.bookCount()) {
            return -1;
        } else {
            CengBook book = this.books.get(index);

            return book.getBookID();
        }
    }

    // Extra Functions
    public CengBook getBook(Integer index) {
        return books.get(index);
    }

    public void addBook(CengBook book) {
        // Insert book to leaf node sorted by bookID
        int i = 0;
        while (i < books.size() && books.get(i).getBookID() < book.getBookID()) {
            i++;
        }
        books.add(i, book);
    }
    /* TODO: Delet Dis */
    public ArrayList<CengBook> getBooks() {
        return books;
    }
}
